
% Control Parameters
Kx = 1;
Ky = 1;
Ktheta = 1;

sim('vehicle_lateral_model_traj_control.slx', Tfinal);


% Plot Result 1
figure(1)

plot(x_r, y_r,'r:');
grid on
hold on
plot(X, Y, 'k');
xlabel('x[meter]');
ylabel('y[meter]');

% Reset Control Parameters
Kx = 1;
Ky = 1;
Ktheta = 2;

sim('vehicle_lateral_model_traj_control.slx', Tfinal);

% Plot Result 2
plot(X, Y, 'b*');

legend('reference trajectory', 'Kx=1, Ky=1, Ktheta=1', 'Kx=1, Ky=1, Ktheta=2');